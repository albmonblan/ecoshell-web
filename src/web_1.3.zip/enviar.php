<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = strip_tags(trim($_POST["nombre"]));
    $apellidos = strip_tags(trim($_POST["apellidos"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $telefono = trim($_POST["telefono"]);
    $perfil = trim($_POST["perfil"]);
    $mensaje = trim($_POST["mensaje"]);

    // Tu email donde recibirás los mensajes
    $destinatario = "albertomonteroblanch@gmail.es"; 
    $asunto = "Nuevo mensaje web de $nombre ($perfil)";

    $contenido = "Nombre: $nombre $apellidos\n";
    $contenido .= "Email: $email\n";
    $contenido .= "Teléfono: $telefono\n";
    $contenido .= "Perfil: $perfil\n\n";
    $contenido .= "Mensaje:\n$mensaje\n";

    $headers = "From: web@upvecomarathon.webs.upv.es";

    if (mail($destinatario, $asunto, $contenido, $headers)) {
        // Redirigir al usuario a una página de gracias
        header("Location: contactanos.html?status=success");
    } else {
        header("Location: contactanos.html?status=error");
    }
} else {
    // Si intentan acceder directamente
    header("Location: contactanos.html");
}
?>